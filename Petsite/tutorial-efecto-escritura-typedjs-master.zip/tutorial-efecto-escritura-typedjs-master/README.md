# Tutorial Efecto de Escritura (ANIMADA) con JAVASCRIPT | Fácil
### [Tutorial: https://youtu.be/bSHitSCqWr8](https://youtu.be/bSHitSCqWr8)

![Efecto de Escritura (ANIMADA) con JAVASCRIPT | Fácil](https://raw.githubusercontent.com/falconmasters/tutorial-efecto-escritura-typedjs/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)